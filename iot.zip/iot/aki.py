import akinator
from speak import takecommand
aki = akinator.Akinator()

q = aki.start_game()

while aki.progression <= 80:
    #newAns = takecommand().lower()
    a = takecommand().lower()

    if a == "b":
        try:
            q = aki.back()
        except akinator.CantGoBackAnyFurther:
            pass
    else:
        if "no" in a:
            q = aki.answer(1)
        elif "yes" in a:
            q = aki.answer(0)
        else:
            print("Error")


aki.win()

correct = input(f"It's {aki.first_guess['name']} ({aki.first_guess['description']})! Was I correct?\n{aki.first_guess['absolute_picture_path']}\n\t")
if correct.lower() == "yes" or correct.lower() == "y":
    print("Yay\n")
else:
    print("Oof\n")